import pygame
import random


pygame.init()
screen = pygame.display.set_mode((600, 400))
pygame.display.set_caption("Раннер")

luntik = pygame.image.load('imgonline-com-ua-Resize-QV3AzvjqFS.png')
fon = pygame.image.load('imgonline-com-ua-Resize-452vA258hfmkUxa.jpg')
fon2 = pygame.image.load('imgonline-com-ua-Resize-q4CZoy8IeS4KER.jpg')
fon1_mini = pygame.image.load('imgonline-com-ua-Resize-PaKxvQa9dwb.jpg')
fon1_mini_rect = fon1_mini.get_rect(topleft=(350, 150))

fon2_mini = pygame.image.load('imgonline-com-ua-Resize-DnRw1Am8KMsm.jpg')
fon2_mini_rect = fon2_mini.get_rect(topleft=(50, 150))
num_fon = 1 


blob = pygame.image.load('imgonline-com-ua-Resize-rqYMrdo5TX.png')
button_play = pygame.image.load('imgonline-com-ua-Resize-oKnxi8vazS.png')
button_play_rect = button_play.get_rect(topleft=(230, 100))
button_shop = pygame.image.load('imgonline-com-ua-Resize-oKnxi8vazS.png')
button_shop_rect = button_shop.get_rect(topleft=(230, 200))
cross = pygame.image.load('imgonline-com-ua-Resize-KBdisivjWjS3pWKW.png')
cross_rect = cross.get_rect(topleft=(530, 10))

luntik_speed = 5
luntik_x = 300
luntik_y = 200



blob_speed = 1
blob_y = -10
blob_x = random.randint(40, 500)

mode = 'menu'

my_font = pygame.font.Font('Roboto-Bold.ttf', 40)
text_gameover = my_font.render('Game Over', True, 'Pink', 'White')
text_play = my_font.render("Play", True, "White")
text_shop = my_font.render("Fon", True, "White")




running = True

#отрисовка
def draw():
    if mode == 'game':
        if num_fon == 1:
            screen.blit(fon, (0, 0))
        elif num_fon == 2:
            screen.blit(fon2, (0, 0))
        screen.blit(luntik, (luntik_x, luntik_y))
        screen.blit(blob, (blob_x, blob_y))
        screen.blit(cross, (530, 10))

    elif mode == 'menu':
        screen.blit(fon, (0, 0))
        screen.blit(button_play, (230, 100))
        screen.blit(button_shop, (230, 200))
        screen.blit(text_play, (280, 110))
        screen.blit(text_shop, (280, 210))

    elif mode == 'shop':
        screen.fill((255, 207, 224))
        screen.blit(fon2_mini, (50, 150))
        screen.blit(fon1_mini, (350, 150))
        screen.blit(cross, (530, 10))

    elif mode == 'game_over':
        screen.blit(fon, (0, 0))
        screen.blit(text_gameover, (230, 200))

#Движение обьектов
def running():
    global luntik_x, blob_y, blob_x, count
    if mode == "game":
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT] and luntik_x > 20:
            luntik_x -= luntik_speed
        elif keys[pygame.K_RIGHT] and luntik_x < 520:
            luntik_x += luntik_speed

        blob_y += blob_speed
        if blob_y > 400:
            blob_y = 20
            blob_x = random.randint(40, 500)
        else:
            blob_y += blob_speed

#столкновения в игре
def logic():
    global mode, num_fon
    if luntik_rect.colliderect(blob_rect) and mode == "game":
        mode = "game_over"

    mouse = pygame.mouse.get_pos()
    if button_play_rect.collidepoint(mouse) and mode == "menu":
        mode = 'game'
    elif button_shop_rect.collidepoint(mouse) and mode == "menu":
        mode = 'shop'

    if cross_rect.collidepoint(mouse):
        mode = 'menu'

    if fon2_mini_rect.collidepoint(mouse) and mode == "shop":
        num_fon = 2
    elif fon1_mini_rect.collidepoint(mouse) and mode == "shop":
        num_fon = 1

while running:
    pygame.display.update()

    luntik_rect = luntik.get_rect(topleft=(luntik_x, luntik_y))
    blob_rect = blob.get_rect(topleft=(blob_x, blob_y))

    draw()

    running()

    logic()


    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
            pygame.quit()
    pygame.time.delay(20)

